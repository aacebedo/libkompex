var searchData=
[
  ['deletetransactionsqlstr',['DeleteTransactionSqlStr',['../class_kompex_1_1_s_q_lite_statement.html#ab014dfa20cc2900763e9265a2a62bd28',1,'Kompex::SQLiteStatement']]]
];
