var searchData=
[
  ['blob_5freadonly',['BLOB_READONLY',['../namespace_kompex.html#a8392b5f95112c2903405bccaed8c53e1a63bb82d432ca4c77b72d3c7d008ef120',1,'Kompex']]],
  ['blob_5freadwrite',['BLOB_READWRITE',['../namespace_kompex.html#a8392b5f95112c2903405bccaed8c53e1ad9ad24d570d8479ab0d61a3ac9634162',1,'Kompex']]]
];
