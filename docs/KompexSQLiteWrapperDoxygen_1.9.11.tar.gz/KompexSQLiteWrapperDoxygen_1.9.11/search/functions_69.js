var searchData=
[
  ['interruptdatabaseoperation',['InterruptDatabaseOperation',['../class_kompex_1_1_s_q_lite_database.html#ac5268073cfa793923ca015878caf94b8',1,'Kompex::SQLiteDatabase']]],
  ['isdatabasereadonly',['IsDatabaseReadOnly',['../class_kompex_1_1_s_q_lite_database.html#a8fa3e5f8a7b89063408d045834eff482',1,'Kompex::SQLiteDatabase']]]
];
