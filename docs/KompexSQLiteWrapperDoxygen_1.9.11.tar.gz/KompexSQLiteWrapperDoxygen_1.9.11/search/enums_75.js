var searchData=
[
  ['utfencoding',['UtfEncoding',['../class_kompex_1_1_s_q_lite_database.html#a4f928b783b9b6ed4b80e1a4703164119',1,'Kompex::SQLiteDatabase']]]
];
