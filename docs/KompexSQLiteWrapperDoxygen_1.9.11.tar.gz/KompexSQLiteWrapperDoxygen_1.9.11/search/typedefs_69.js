var searchData=
[
  ['int64',['int64',['../_kompex_s_q_lite_prerequisites_8h.html#afe4e545a078b427a79aafde0ed7dc948',1,'KompexSQLitePrerequisites.h']]]
];
