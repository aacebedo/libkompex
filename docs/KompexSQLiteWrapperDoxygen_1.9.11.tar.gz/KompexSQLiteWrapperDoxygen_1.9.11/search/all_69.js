var searchData=
[
  ['int64',['int64',['../_kompex_s_q_lite_prerequisites_8h.html#afe4e545a078b427a79aafde0ed7dc948',1,'KompexSQLitePrerequisites.h']]],
  ['interruptdatabaseoperation',['InterruptDatabaseOperation',['../class_kompex_1_1_s_q_lite_database.html#ac5268073cfa793923ca015878caf94b8',1,'Kompex::SQLiteDatabase']]],
  ['isdatabasereadonly',['IsDatabaseReadOnly',['../class_kompex_1_1_s_q_lite_database.html#a8fa3e5f8a7b89063408d045834eff482',1,'Kompex::SQLiteDatabase']]]
];
