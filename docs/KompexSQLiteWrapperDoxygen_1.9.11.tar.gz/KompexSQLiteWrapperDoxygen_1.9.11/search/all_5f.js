var searchData=
[
  ['_5fsqlitewrapperexport',['_SQLiteWrapperExport',['../_kompex_s_q_lite_prerequisites_8h.html#a5afca283ae929b30576f57127c1b6b6d',1,'KompexSQLitePrerequisites.h']]]
];
